
import { useToast } from "@/components/ui/use-toast"

export { toast } from "@/components/ui/use-toast"
export { useToast }
